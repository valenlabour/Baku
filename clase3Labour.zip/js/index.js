let entrada = prompt('Ingrese su estado civil ("*" para terminar)')

while (entrada !== '*'){
        switch (entrada.toLowerCase()) {
            case 'casado':
                alert('Su estado civil es ' + entrada)
                break
            case 'soltero':
                alert('Su estado civil es ' + entrada)
                break
            default:
                entrada = prompt('Ingrese su estado civil ("*" para terminar)')
        }
        break
}